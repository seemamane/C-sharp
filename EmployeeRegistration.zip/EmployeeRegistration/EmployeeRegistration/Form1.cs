﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using Excel = Microsoft.Office.Interop.Excel;
using System.Text.RegularExpressions;

namespace EmployeeRegistration
{
    public partial class Form1 : Form
    {
        int i, j;
        Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {


            

            if (xlApp == null)
            {
                MessageBox.Show("Excel is not properly installed!!");
                return;
            }
            Excel.Workbook xlWorkBook;
            Excel.Worksheet xlWorkSheet;
            object misValue = System.Reflection.Missing.Value;
         

            xlWorkBook = xlApp.Workbooks.Open("d:\\csharp1-Excel.xls");
            xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);
            //xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets[1];
          
            if (txtID.Text == "")
            {
                MessageBox.Show("emp id cant be empty!!");
                return;
            }
            else
                if (txtFname.Text == "")
                {
                    MessageBox.Show("first name  cant be empty !!");
                    return;
                }

                else
                    if (txtLname.Text == "")
                    {
                        MessageBox.Show("Last name cant be empty!!");
                        return;
                    }
                    else
                        if (txtAddress.Text == "")
                        {
                            MessageBox.Show("address cant be empty!!");
                            return;
                        }
                        else
                            if (dob.Text == "")
                            {
                                MessageBox.Show("DOB cant be empty!!");
                                return;
                            }
                            else
                                if (txtContact.Text == "")
                                {
                                    MessageBox.Show("contact cant be empty!!");
                                    return;
                                }
                                else
                                    if (combo_designation.Text == "")
                                    {
                                        MessageBox.Show("Designation cant be empty!!");
                                        return;
                                    }
                                    else
                                        if (txtSalary.Text == "")
                                        {
                                            MessageBox.Show("Salary name cant be empty!!");
                                            return;
                                        }
                                        else
                                            if (combo_department.Text == "")
                                            {
                                                MessageBox.Show("dept. cant be empty!!");
                                                return;
                                            }
          int lastUsedRow = xlWorkSheet.Cells.SpecialCells(Excel.XlCellType.xlCellTypeLastCell, misValue).Row;
            int a = lastUsedRow + 1;


            xlWorkSheet.Cells[1, 1] = "Employee ID";
            xlWorkSheet.Cells[1, 2] = "First Name";
            xlWorkSheet.Cells[1, 3] = "Last Name";
            xlWorkSheet.Cells[1, 4] = "Address";
            xlWorkSheet.Cells[1, 5] = "Date of Birth";
            xlWorkSheet.Cells[1, 6] = "Contact";
            xlWorkSheet.Cells[1, 7] = "Designation";
            xlWorkSheet.Cells[1, 8] = "Salary";
            xlWorkSheet.Cells[1, 9] = "Department";




            xlWorkSheet.Cells[a, 1] = txtID.Text;
            xlWorkSheet.Cells[a, 2] = txtFname.Text;
            xlWorkSheet.Cells[a, 3] = txtLname.Text;
            xlWorkSheet.Cells[a, 4] = txtAddress.Text;
            xlWorkSheet.Cells[a, 5] = dob.Text;
            xlWorkSheet.Cells[a, 6] = txtContact.Text;
            xlWorkSheet.Cells[a, 7] = combo_designation.Text;
            xlWorkSheet.Cells[a, 8] = txtSalary.Text;
            xlWorkSheet.Cells[a, 9] = combo_department.Text;
            int b = 10000 + a;
            int c;
            c = Convert.ToInt32(txtID.Text);

            if (c == b)
            { 
                MessageBox.Show("Employee ID already exist."); 
            }
            else
            {
                xlWorkBook.Save();
                xlWorkBook.Close(true, misValue, misValue);
                xlApp.Quit();
             
                Marshal.ReleaseComObject(xlWorkSheet);
                Marshal.ReleaseComObject(xlWorkBook);
                Marshal.ReleaseComObject(xlApp);
                MessageBox.Show("Excel file created , you can find the file d:\\csharp1-Excel.xls");
            }
   

        }

      private void textBox1_TextChanged(object sender, EventArgs e)
        {

            txtID.MaxLength = 5;
            if (int.TryParse(txtID.Text.ToString(), out i))
            {
                i = Convert.ToInt32(txtID.Text);
            }
            else
            {
              if (txtID.Text.Length >= 1)
                {
                    txtID.Text = txtID.Text.Remove(txtID.Text.Length - 1);
                    MessageBox.Show("Enter numbers only");
                    return;
               }
        
            }
  
 
  
        }
        //Add values in Combo box
      private void Form1_Load(object sender, EventArgs e)
      {
          combo_department.Items.Add("IT");
          combo_department.Items.Add("ADMIN");
          combo_department.Items.Add("Facilities");
          combo_department.Items.Add("HR");
          combo_designation.Items.Add("CONSULTANT");
          combo_designation.Items.Add("SR. CONSULTANT");
          combo_designation.Items.Add("LEAD CONSULTANT");
          combo_designation.Items.Add("MANAGER");
          combo_designation.Items.Add("SR. MANAGER");
      }


        //Reset 
      private void reset_Click(object sender, EventArgs e)
      {
          txtID.Text = "";
          txtFname.Text = "";
          txtLname.Text = "";
          txtAddress.Text = "";
          dob.Text = "";
          txtContact.Text = "";
          combo_department.Text = "";
          txtSalary.Text = "";
          combo_designation.Text = "";
      }

      private void txtFname_TextChanged(object sender, EventArgs e)
      {

          if (System.Text.RegularExpressions.Regex.IsMatch(txtFname.Text, "^[a-zA-Z]+$"))
          {
          }
          else
          {
              if (txtFname.Text.Length >= 1)
              {
                  txtFname.Text = txtFname.Text.Remove(txtFname.Text.Length - 1);
                  MessageBox.Show("Enter only Alphabets");
                  return;
              }
          }
      }


      private void txtLname_TextChanged(object sender, EventArgs e)
      {

          if (System.Text.RegularExpressions.Regex.IsMatch(txtLname.Text, "^[a-zA-Z]+$"))
          {

          }
          else
          {
              if (txtLname.Text.Length >= 1)
              {
                  txtLname.Text = txtLname.Text.Remove(txtLname.Text.Length - 1);
                  MessageBox.Show("Enter only Alphabets");
                  return;
              }
          }  
      }

      private void txtContact_TextChanged(object sender, EventArgs e)
      {
          txtContact.MaxLength = 10;
          if (int.TryParse(txtContact.Text.ToString(), out j))
          {
              j = Convert.ToInt32(txtContact.Text);
          }

          else
          {
              if (txtContact.Text.Length >= 9)
              {

              }
              else if (txtContact.Text.Length >= 1)
              {
                  txtContact.Text = txtContact.Text.Remove(txtContact.Text.Length - 1);
                  MessageBox.Show("Enter numbers only");
                  return;
              }
             
          }
      }

      private void txtSalary_TextChanged(object sender, EventArgs e)
      {
          Double sal;
          sal = Convert.ToDouble(txtSalary.Text);
          if (sal <= 0) {
              MessageBox.Show("Salary should be greater than Zero");
          }

      }

      private void close_Click(object sender, EventArgs e)
      {
          Application.Exit();
      }

     
        
    }
}
