﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using Excel = Microsoft.Office.Interop.Excel;

namespace EmployeeRegistration1
{
    public partial class Form1 : Form
    {

       
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void btnFirst_Click(object sender, EventArgs e)
        {
            Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
         

            if (xlApp == null)
            {
                MessageBox.Show("Excel is not properly installed!!");
                return;
            }
            Excel.Workbook xlWorkBook;
            Excel.Worksheet xlWorkSheet;
            object misValue = System.Reflection.Missing.Value;

            xlWorkBook = xlApp.Workbooks.Open("d:\\csharp1-Excel.xls");
            xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets[1];
            txtID.Text = Convert.ToString(xlWorkSheet.Cells[2, 1].value);
            txtFname.Text = Convert.ToString(xlWorkSheet.Cells[2, 2].value);
            txtLname.Text = Convert.ToString(xlWorkSheet.Cells[2, 3].value);
            txtAddress.Text = Convert.ToString(xlWorkSheet.Cells[2, 4].value);
            txtDOB.Text = Convert.ToString(xlWorkSheet.Cells[2, 5].value);
            txtContact.Text = Convert.ToString(xlWorkSheet.Cells[2, 6].value);
            txtDesignation.Text = Convert.ToString(xlWorkSheet.Cells[2, 7].value);
            txtSalary.Text = Convert.ToString(xlWorkSheet.Cells[2, 8].value);
            txtDepartment.Text = Convert.ToString(xlWorkSheet.Cells[2, 9].value);
            btnNext.Enabled = true;
            btnPrev.Enabled = false;
            //xlWorkBook.Save();
            xlWorkBook.Close(true, misValue, misValue);
            xlApp.Quit();
            Marshal.ReleaseComObject(xlWorkSheet);
            Marshal.ReleaseComObject(xlWorkBook);
            Marshal.ReleaseComObject(xlApp);

        }

        private void btnLast_Click(object sender, EventArgs e)
        {
            Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
          

            if (xlApp == null)
            {
                MessageBox.Show("Excel is not properly installed!!");
                return;
            }
            Excel.Workbook xlWorkBook;
            Excel.Worksheet xlWorkSheet;
            object misValue = System.Reflection.Missing.Value;
            xlWorkBook = xlApp.Workbooks.Open("d:\\csharp1-Excel.xls");
            xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets[1];

            int lastUsedRow = xlWorkSheet.Cells.SpecialCells(Excel.XlCellType.xlCellTypeLastCell, misValue).Row;
            txtID.Text = Convert.ToString(xlWorkSheet.Cells[lastUsedRow, 1].value);
            txtFname.Text = Convert.ToString(xlWorkSheet.Cells[lastUsedRow, 2].value);
            txtLname.Text = Convert.ToString(xlWorkSheet.Cells[lastUsedRow, 3].value);
            txtAddress.Text = Convert.ToString(xlWorkSheet.Cells[lastUsedRow, 4].value);
            txtDOB.Text = Convert.ToString(xlWorkSheet.Cells[lastUsedRow, 5].value);
            txtContact.Text = Convert.ToString(xlWorkSheet.Cells[lastUsedRow, 6].value);
            txtDesignation.Text = Convert.ToString(xlWorkSheet.Cells[lastUsedRow, 7].value);
            txtSalary.Text = Convert.ToString(xlWorkSheet.Cells[lastUsedRow, 8].value);
            txtDepartment.Text = Convert.ToString(xlWorkSheet.Cells[lastUsedRow, 9].value);
            //xlWorkBook.Save();
            btnNext.Enabled = false;
            btnPrev.Enabled = true;
            xlWorkBook.Close(true, misValue, misValue);
            xlApp.Quit();
            Marshal.ReleaseComObject(xlWorkSheet);
            Marshal.ReleaseComObject(xlWorkBook);
            Marshal.ReleaseComObject(xlApp);
        }

        private void btnPrev_Click(object sender, EventArgs e)
        {
            Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();

            if (xlApp == null)
            {
                MessageBox.Show("Excel is not properly installed!!");
                return;
            }
            Excel.Workbook xlWorkBook;
            Excel.Worksheet xlWorkSheet;
            object misValue = System.Reflection.Missing.Value;

            xlWorkBook = xlApp.Workbooks.Open("d:\\csharp1-Excel.xls");
            xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets[1];

            int i;
            if (int.TryParse(txtID.Text.ToString(), out i) && (txtID.Text.Length == 5))
            {

                i = Convert.ToInt32(txtID.Text);


                int lastUsedRow = xlWorkSheet.Cells.SpecialCells(Excel.XlCellType.xlCellTypeLastCell, misValue).Row;
                int a = lastUsedRow + 1;
                string p;

                for (int x = 2; x <= a; x = x + 1)
                {
                    p = Convert.ToString(xlWorkSheet.Cells[x, 1].value);

                    if (i == Convert.ToInt32(p))
                    {
                        int y = x - 1;

                        txtID.Text = Convert.ToString(xlWorkSheet.Cells[y, 1].value);
                        txtFname.Text = Convert.ToString(xlWorkSheet.Cells[y, 2].value);
                        txtLname.Text = Convert.ToString(xlWorkSheet.Cells[y, 3].value);
                        txtAddress.Text = Convert.ToString(xlWorkSheet.Cells[y, 4].value);
                        txtDOB.Text = Convert.ToString(xlWorkSheet.Cells[y, 5].value);
                        txtContact.Text = Convert.ToString(xlWorkSheet.Cells[y, 6].value);
                        txtDesignation.Text = Convert.ToString(xlWorkSheet.Cells[y, 7].value);
                        txtSalary.Text = Convert.ToString(xlWorkSheet.Cells[y, 8].value);
                        txtDepartment.Text = Convert.ToString(xlWorkSheet.Cells[y, 9].value);
                        if (y == 2)
                        {
                            btnPrev.Enabled = false;
                            return;
                        }
                        else
                        {
                            btnPrev.Enabled = true;
                            btnNext.Enabled = true;
                            return;


                        }
                        return;
                    }
                    else if (x == a)
                    {
                        foreach (var tb in Controls.OfType<TextBox>())
                        {
                            tb.Text = null;
                        }
                        MessageBox.Show(i + "This Emp code does not Exist");
                        btnNext.Enabled = true;
                        return;
                    }
                }


            }
            else
            {
                txtFname.Text = "";
                txtLname.Text = "";
                txtAddress.Text = "";
                txtDOB.Text = "";
                txtContact.Text = "";
                txtDesignation.Text = "";
                txtSalary.Text = "";
                txtDepartment.Text = "";
                MessageBox.Show("Please Enter valid Emp Id");
                return;
            }
            xlWorkBook.Save();
            xlWorkBook.Close(true, misValue, misValue);
            xlApp.Quit();
            Marshal.ReleaseComObject(xlWorkSheet);
            Marshal.ReleaseComObject(xlWorkBook);
            Marshal.ReleaseComObject(xlApp);
            
        }

        private void btnNext_Click(object sender, EventArgs e)
        {

            Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
            if (xlApp == null)
            {
                MessageBox.Show("Excel is not properly installed!!");
                return;
            }
            Excel.Workbook xlWorkBook;
            Excel.Worksheet xlWorkSheet;
            object misValue = System.Reflection.Missing.Value;

            xlWorkBook = xlApp.Workbooks.Open("d:\\csharp1-Excel.xls");
            xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets[1];

            int i;
            if (int.TryParse(txtID.Text.ToString(), out i) && (txtID.Text.Length == 5))
            {

                i = Convert.ToInt32(txtID.Text);


                int lastUsedRow = xlWorkSheet.Cells.SpecialCells(Excel.XlCellType.xlCellTypeLastCell, misValue).Row;
                int a = lastUsedRow + 1;
                string p;

                for (int x = 2; x <= a; x = x + 1)
                {
                    p = Convert.ToString(xlWorkSheet.Cells[x, 1].value);

                    if (i == Convert.ToInt32(p))
                    {
                        int y = x + 1;

                        txtID.Text = Convert.ToString(xlWorkSheet.Cells[y, 1].value);
                        txtFname.Text = Convert.ToString(xlWorkSheet.Cells[y, 2].value);
                        txtLname.Text = Convert.ToString(xlWorkSheet.Cells[y, 3].value);
                        txtAddress.Text = Convert.ToString(xlWorkSheet.Cells[y, 4].value);
                        txtDOB.Text = Convert.ToString(xlWorkSheet.Cells[y, 5].value);
                        txtContact.Text = Convert.ToString(xlWorkSheet.Cells[y, 6].value);
                        txtDesignation.Text = Convert.ToString(xlWorkSheet.Cells[y, 7].value);
                        txtSalary.Text = Convert.ToString(xlWorkSheet.Cells[y, 8].value);
                        txtDepartment.Text = Convert.ToString(xlWorkSheet.Cells[y, 9].value);
                        if (y == lastUsedRow)
                        {
                            btnNext.Enabled = false;
                            return;
                        }

                        else
                        {
                            btnPrev.Enabled = true;
                            btnNext.Enabled = true;
                            return;


                        }
                        return;
                    }
                    else if (x == a)
                    {
                        foreach (var tb in Controls.OfType<TextBox>())
                        {
                            tb.Text = null;
                        }
                        MessageBox.Show(i + "This Emp code does not Exist");
                        btnNext.Enabled = true;
                        return;
                    }
                }


            }
            else
            {
                txtFname.Text = "";
                txtLname.Text = "";
                txtAddress.Text = "";
                txtDOB.Text = "";
                txtContact.Text = "";
                txtDesignation.Text = "";
                txtSalary.Text = "";
                txtDepartment.Text = "";
                MessageBox.Show("Please Enter valid Emp Id");
                return;
            }
            xlWorkBook.Save();
            xlWorkBook.Close(true, misValue, misValue);
            xlApp.Quit();
            Marshal.ReleaseComObject(xlWorkSheet);
            Marshal.ReleaseComObject(xlWorkBook);
            Marshal.ReleaseComObject(xlApp);
            
            
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {

            Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
            if (xlApp == null)
            {
                MessageBox.Show("Excel is not properly installed!!");
                return;
            }
            Excel.Workbook xlWorkBook;
            Excel.Worksheet xlWorkSheet;
            object misValue = System.Reflection.Missing.Value;

            xlWorkBook = xlApp.Workbooks.Open("d:\\csharp1-Excel.xls");
            xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets[1];

            int i;
            if (int.TryParse(txtID.Text.ToString(), out i) && (txtID.Text.Length == 5))
            {

                i = Convert.ToInt32(txtID.Text);


                int lastUsedRow = xlWorkSheet.Cells.SpecialCells(Excel.XlCellType.xlCellTypeLastCell, misValue).Row;
                int a = lastUsedRow + 1;
                string p;

                for (int x = 2; x <= a; x = x + 1)
                {
                    p = Convert.ToString(xlWorkSheet.Cells[x, 1].value);

                    if (i == Convert.ToInt32(p))
                    {
                        txtID.Text = Convert.ToString(xlWorkSheet.Cells[x, 1].value);
                        txtFname.Text = Convert.ToString(xlWorkSheet.Cells[x, 2].value);
                        txtLname.Text = Convert.ToString(xlWorkSheet.Cells[x, 3].value);
                        txtAddress.Text = Convert.ToString(xlWorkSheet.Cells[x, 4].value);
                        txtDOB.Text = Convert.ToString(xlWorkSheet.Cells[x, 5].value);
                        txtContact.Text = Convert.ToString(xlWorkSheet.Cells[x, 6].value);
                        txtDesignation.Text = Convert.ToString(xlWorkSheet.Cells[x, 7].value);
                        txtSalary.Text = Convert.ToString(xlWorkSheet.Cells[x, 8].value);
                        txtDepartment.Text = Convert.ToString(xlWorkSheet.Cells[x, 9].value);
                        if (x == lastUsedRow)
                        {
                            btnNext.Enabled = false;
                            return;
                        }
                        else if (x == 2)
                        {
                            btnPrev.Enabled = false;
                            return;
                        }
                        else
                        {
                            btnPrev.Enabled = true;
                            btnNext.Enabled = true;
                            return;


                        }
                        return;
                    }
                    else if (x == a)
                    {
                        foreach (var tb in Controls.OfType<TextBox>())
                        {
                            tb.Text = null;
                        }
                        MessageBox.Show(i + "This Emp code does not Exist");
                        btnNext.Enabled = true;
                        return;
                    }
                }


            }
            else
            {
                txtFname.Text = "";
                txtLname.Text = "";
                txtAddress.Text = "";
                txtDOB.Text = "";
                txtContact.Text = "";
                txtDesignation.Text = "";
                txtSalary.Text = "";
                txtDepartment.Text = "";
                MessageBox.Show("Please Enter valid Emp Id");
                return;
            }
            xlWorkBook.Save();
            xlWorkBook.Close(true, misValue, misValue);
            xlApp.Quit();
            Marshal.ReleaseComObject(xlWorkSheet);
            Marshal.ReleaseComObject(xlWorkBook);
            Marshal.ReleaseComObject(xlApp);
        }

       
    }
}
