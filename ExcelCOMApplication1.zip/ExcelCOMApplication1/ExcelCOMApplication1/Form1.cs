﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using Excel = Microsoft.Office.Interop.Excel; 


namespace ExcelCOMApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
       
         Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();

            
        private void button1_Click(object sender, EventArgs e)
        {

            if (xlApp == null)
            {
                MessageBox.Show("Excel is not properly installed!!");
                return;
            }
           Excel.Workbook xlWorkBook;
            Excel.Worksheet xlWorkSheet;
            object misValue = System.Reflection.Missing.Value;
            xlWorkBook = xlApp.Workbooks.Add(misValue);
            xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);
            xlWorkSheet.Cells[1, 1] = "ID";
            xlWorkSheet.Cells[1, 2] = "Name";
            xlWorkSheet.Cells[2, 1] = "1";
            xlWorkSheet.Cells[2, 2] = "One";
            xlWorkSheet.Cells[3, 1] = "2";
            xlWorkSheet.Cells[3, 2] = "Two";
            xlWorkBook.SaveAs("d:\\csharp1-Excel.xls", Excel.XlFileFormat.xlWorkbookNormal, misValue, misValue, misValue, misValue, Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
            xlWorkBook.Close(true, misValue, misValue);
            xlApp.Quit();
            Marshal.ReleaseComObject(xlWorkSheet);
            Marshal.ReleaseComObject(xlWorkBook);
            //Marshal.ReleaseComObject(xlApp);
          // MessageBox.Show("Excel file created , you can find the file d:\\csharp-Excel.xls");

        }

        private void button2_Click(object sender, EventArgs e)
        {

            Excel.Workbook xlWorkBook;
            Excel.Worksheet xlWorkSheet;
            object misValue = System.Reflection.Missing.Value;
           // xlWorkBook = xlApp.Workbooks.Add(misValue);
            xlWorkBook = xlApp.Workbooks.Open("d:\\csharp1-Excel.xls");
            xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);
            //xlWorkSheet.Cells[1, 3] = "ID";
           // xlWorkSheet.Cells[1, 4] = "Name";
            xlWorkSheet.Cells[4, 1] = "3";
            xlWorkSheet.Cells[4, 2] = "three";
            xlWorkSheet.Cells[5, 1] = "4";
            xlWorkSheet.Cells[5, 2] = "four";
            xlWorkBook.Save();
           // xlWorkBook.SaveAs("d:\\csharp1-Excel.xls", Excel.XlFileFormat.xlWorkbookNormal, misValue, misValue, misValue, misValue, Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
            xlWorkBook.Close(true, misValue, misValue);
            xlApp.Quit();
            Marshal.ReleaseComObject(xlWorkSheet);
            Marshal.ReleaseComObject(xlWorkBook);
            //Marshal.ReleaseComObject(xlApp);
            //MessageBox.Show("Excel file created , you can find the file d:\\csharp-Excel.xls");

        }

        private void button3_Click(object sender, EventArgs e)
        {

            Excel.Workbook xlWorkBook;
            Excel.Worksheet xlWorkSheet;
            object misValue = System.Reflection.Missing.Value;
            //xlWorkBook = xlApp.Workbooks.Add(misValue);
            xlWorkBook = xlApp.Workbooks.Open("d:\\csharp1-Excel.xls");
            xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);
            //xlWorkSheet.Cells[1, 3] = "ID";
            // xlWorkSheet.Cells[1, 4] = "Name";
            xlWorkSheet.Cells[6, 1] = "5";
            xlWorkSheet.Cells[6, 2] = "five";
            xlWorkSheet.Cells[7, 1] = "6";
            xlWorkSheet.Cells[7, 2] = "six";
            xlWorkBook.Save();
            // xlWorkBook.SaveAs("d:\\csharp1-Excel.xls", Excel.XlFileFormat.xlWorkbookNormal, misValue, misValue, misValue, misValue, Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
            xlWorkBook.Close(true, misValue, misValue);
            xlApp.Quit();
            Marshal.ReleaseComObject(xlWorkSheet);
            Marshal.ReleaseComObject(xlWorkBook);
           // Marshal.ReleaseComObject(xlApp);
          //  MessageBox.Show("Excel file created , you can find the file d:\\csharp-Excel.xls");
        }

        private void button4_Click(object sender, EventArgs e)
        {

            Excel.Workbook xlWorkBook;
            Excel.Worksheet xlWorkSheet;
            object misValue = System.Reflection.Missing.Value;
            //xlWorkBook = xlApp.Workbooks.Add(misValue);
            xlWorkBook = xlApp.Workbooks.Open("d:\\csharp1-Excel.xls");
            xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);
            //xlWorkSheet.Cells[1, 3] = "ID";
            // xlWorkSheet.Cells[1, 4] = "Name";
            xlWorkSheet.Cells[8, 1] = "7";
            xlWorkSheet.Cells[8, 2] = "seven";
            xlWorkSheet.Cells[9, 1] = "8";
            xlWorkSheet.Cells[9, 2] = "eight";
            xlWorkBook.Save();
            // xlWorkBook.SaveAs("d:\\csharp1-Excel.xls", Excel.XlFileFormat.xlWorkbookNormal, misValue, misValue, misValue, misValue, Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
            xlWorkBook.Close(true, misValue, misValue);
            xlApp.Quit();
            Marshal.ReleaseComObject(xlWorkSheet);
            Marshal.ReleaseComObject(xlWorkBook);
            Marshal.ReleaseComObject(xlApp);
            MessageBox.Show("Excel file created , you can find the file d:\\csharp-Excel.xls");
        }
    }
}
